/* ============================================================
   app.js — Main JavaScript
   POE Part 3: Functionality, SEO, Forms & Validation
   ============================================================ */

'use strict';

/* ── Helpers ─────────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ──────────────────────────────────────────────────────────
   1. NAVIGATION — hamburger toggle & active link
──────────────────────────────────────────────────────────── */
function initNav() {
  const toggle = $('.nav__toggle');
  const links  = $('.nav__links');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    const isOpen = toggle.classList.toggle('open');
    links.classList.toggle('open', isOpen);
    toggle.setAttribute('aria-expanded', isOpen);
  });

  // Close on link click (mobile)
  $$('a', links).forEach(a => {
    a.addEventListener('click', () => {
      toggle.classList.remove('open');
      links.classList.remove('open');
      toggle.setAttribute('aria-expanded', false);
    });
  });

  // Highlight active nav link
  const current = location.pathname.split('/').pop() || 'index.html';
  $$('.nav__links a').forEach(a => {
    const href = a.getAttribute('href').split('/').pop();
    if (href === current) a.classList.add('active');
  });
}

/* ──────────────────────────────────────────────────────────
   2. SCROLL-TO-TOP BUTTON
──────────────────────────────────────────────────────────── */
function initScrollTop() {
  const btn = $('.scroll-top');
  if (!btn) return;
  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* ──────────────────────────────────────────────────────────
   3. ACCORDION
──────────────────────────────────────────────────────────── */
function initAccordions() {
  $$('.accordion-item__header').forEach(header => {
    header.addEventListener('click', () => {
      const item = header.closest('.accordion-item');
      const wasOpen = item.classList.contains('open');
      // Close siblings (optional single-open behaviour)
      $$('.accordion-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });
}

/* ──────────────────────────────────────────────────────────
   4. TABS
──────────────────────────────────────────────────────────── */
function initTabs() {
  $$('.tabs').forEach(tabGroup => {
    const buttons = $$('.tab-btn', tabGroup);
    const panels  = $$('.tab-panel', tabGroup);

    buttons.forEach((btn, i) => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        panels.forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        panels[i] && panels[i].classList.add('active');
      });
    });
  });
}

/* ──────────────────────────────────────────────────────────
   5. LIGHTBOX GALLERY
──────────────────────────────────────────────────────────── */
function initLightbox() {
  const lightbox = $('.lightbox');
  if (!lightbox) return;

  const lbImg   = $('.lightbox__img', lightbox);
  const lbClose = $('.lightbox__close', lightbox);

  $$('.gallery-item[data-src]').forEach(item => {
    item.addEventListener('click', () => {
      lbImg.src = item.dataset.src;
      lbImg.alt = item.dataset.caption || '';
      lightbox.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
    // Keyboard
    item.setAttribute('tabindex', '0');
    item.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') item.click();
    });
  });

  const close = () => {
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
    lbImg.src = '';
  };

  lbClose.addEventListener('click', close);
  lightbox.addEventListener('click', e => { if (e.target === lightbox) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
}

/* ──────────────────────────────────────────────────────────
   6. SEARCH & FILTER (services / events page)
──────────────────────────────────────────────────────────── */
function initFilter() {
  const searchInput = $('#searchInput');
  const filterBtns  = $$('.filter-btn');
  const items        = $$('[data-category]');
  if (!items.length) return;

  let activeCategory = 'all';
  let searchTerm     = '';

  function applyFilter() {
    items.forEach(item => {
      const cat   = item.dataset.category || '';
      const text  = item.textContent.toLowerCase();
      const matchCat  = activeCategory === 'all' || cat === activeCategory;
      const matchSearch = text.includes(searchTerm);
      item.style.display = (matchCat && matchSearch) ? '' : 'none';
    });
  }

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.dataset.filter || 'all';
      applyFilter();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      searchTerm = searchInput.value.toLowerCase().trim();
      applyFilter();
    });
  }
}

/* ──────────────────────────────────────────────────────────
   7. TOAST NOTIFICATIONS
──────────────────────────────────────────────────────────── */
function showToast(message, type = 'success') {
  let container = $('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3600);
}

/* ──────────────────────────────────────────────────────────
   8. FORM VALIDATION — shared helpers
──────────────────────────────────────────────────────────── */
const validators = {
  required:  v => v.trim() !== '',
  email:     v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  phone:     v => /^[\d\s\+\-\(\)]{7,15}$/.test(v.trim()),
  minLen:    (v, n) => v.trim().length >= n,
  maxLen:    (v, n) => v.trim().length <= n,
  numeric:   v => /^\d+(\.\d+)?$/.test(v.trim()),
};

function validateField(group) {
  const input  = group.querySelector('input, select, textarea');
  if (!input) return true;
  const rules  = input.dataset.validate ? input.dataset.validate.split('|') : [];
  const errEl  = group.querySelector('.field-error');
  let valid = true;
  let message = '';

  for (const rule of rules) {
    const [name, arg] = rule.split(':');
    if (name === 'required'  && !validators.required(input.value))    { valid = false; message = 'This field is required.'; break; }
    if (name === 'email'     && !validators.email(input.value))       { valid = false; message = 'Please enter a valid email address.'; break; }
    if (name === 'phone'     && !validators.phone(input.value))       { valid = false; message = 'Please enter a valid phone number.'; break; }
    if (name === 'minLen'    && !validators.minLen(input.value, +arg)){ valid = false; message = `Minimum ${arg} characters required.`; break; }
    if (name === 'maxLen'    && !validators.maxLen(input.value, +arg)){ valid = false; message = `Maximum ${arg} characters allowed.`; break; }
    if (name === 'numeric'   && !validators.numeric(input.value))     { valid = false; message = 'Please enter a valid number.'; break; }
  }

  group.classList.toggle('valid',   valid && input.value.trim() !== '');
  group.classList.toggle('invalid', !valid);
  if (errEl) errEl.textContent = message;
  return valid;
}

function initFormValidation(formSel, submitCallback) {
  const form = $(formSel);
  if (!form) return;

  const groups = $$('.form-group', form);

  // Real-time validation on blur
  groups.forEach(group => {
    const input = group.querySelector('input, select, textarea');
    if (input) input.addEventListener('blur', () => validateField(group));
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const allValid = groups.map(validateField).every(Boolean);
    if (!allValid) {
      showToast('Please fix the errors before submitting.', 'error');
      return;
    }
    submitCallback && submitCallback(form);
  });
}

/* ──────────────────────────────────────────────────────────
   9. ENQUIRY FORM (enquiry.html)
──────────────────────────────────────────────────────────── */
function initEnquiryForm() {
  initFormValidation('#enquiryForm', form => {
    const data = new FormData(form);
    const payload = Object.fromEntries(data.entries());
    console.log('Enquiry payload:', payload);
    showToast('Your enquiry has been sent! We\'ll be in touch soon.', 'success');
    form.reset();
    $$('.form-group', form).forEach(g => g.classList.remove('valid', 'invalid'));
  });
}

/* ──────────────────────────────────────────────────────────
   10. CONTACT FORM (contact.html) — with AJAX simulation
──────────────────────────────────────────────────────────── */
function initContactForm() {
  initFormValidation('#contactForm', async form => {
    const submitBtn = $('[type="submit"]', form);
    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending…';

    try {
      // Simulate AJAX call (replace with real endpoint)
      await new Promise(resolve => setTimeout(resolve, 1200));
      showToast('Message sent! Thank you for reaching out.', 'success');
      form.reset();
      $$('.form-group', form).forEach(g => g.classList.remove('valid', 'invalid'));
    } catch {
      showToast('Something went wrong. Please try again.', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Send Message';
    }
  });
}

/* ──────────────────────────────────────────────────────────
   11. DYNAMIC CONTENT LOADER (posts / product listings)
──────────────────────────────────────────────────────────── */
function initDynamicContent() {
  const grid     = $('#dynamicGrid');
  const loadMore = $('#loadMoreBtn');
  if (!grid || !loadMore) return;

  // Sample data (replace with real API)
  const allItems = [
    { title: 'Community Garden', cat: 'events',   desc: 'Join us for our seasonal planting day in the heart of the city.' },
    { title: 'Tech Workshop',    cat: 'services',  desc: 'Free coding bootcamp for beginners every Saturday morning.' },
    { title: 'Art Exhibition',   cat: 'events',    desc: 'Local artists showcase their work in our gallery space.' },
    { title: 'Mentorship Drive', cat: 'volunteer', desc: 'Pair up with a mentor and accelerate your career growth.' },
    { title: 'Food Pantry',      cat: 'services',  desc: 'Weekly food distribution supporting 200+ families each month.' },
    { title: 'Youth Coding',     cat: 'services',  desc: 'After-school coding programme for ages 10–16.' },
    { title: 'Charity Run 5K',   cat: 'events',    desc: 'Annual fundraising run through the city park.' },
    { title: 'Skills Training',  cat: 'volunteer', desc: 'Teach your professional skills to community members in need.' },
  ];

  let page = 0;
  const perPage = 4;

  function renderItems() {
    const slice = allItems.slice(page * perPage, (page + 1) * perPage);
    slice.forEach(item => {
      const el = document.createElement('div');
      el.className = 'card';
      el.dataset.category = item.cat;
      el.innerHTML = `
        <span class="text-mono text-muted">${item.cat}</span>
        <h3 style="margin-top:0.5rem;margin-bottom:0.75rem">${item.title}</h3>
        <p class="text-muted" style="margin:0">${item.desc}</p>
      `;
      grid.appendChild(el);
    });
    page++;
    if (page * perPage >= allItems.length) loadMore.style.display = 'none';
  }

  renderItems();
  loadMore.addEventListener('click', renderItems);
}

/* ──────────────────────────────────────────────────────────
   12. ANIMATE ON SCROLL (IntersectionObserver)
──────────────────────────────────────────────────────────── */
function initScrollAnimations() {
  if (!('IntersectionObserver' in window)) return;

  const style = document.createElement('style');
  style.textContent = `
    .reveal { opacity: 0; transform: translateY(28px); transition: opacity 0.6s ease, transform 0.6s ease; }
    .reveal.visible { opacity: 1; transform: translateY(0); }
  `;
  document.head.appendChild(style);

  $$('.card, .section-header, .stats-strip, .gallery-item').forEach((el, i) => {
    el.classList.add('reveal');
    el.style.transitionDelay = `${(i % 4) * 80}ms`;
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });

  $$('.reveal').forEach(el => observer.observe(el));
}

/* ──────────────────────────────────────────────────────────
   13. INTERACTIVE MAP (Leaflet)
──────────────────────────────────────────────────────────── */
function initMap() {
  const mapEl = document.getElementById('leafletMap');
  if (!mapEl || typeof L === 'undefined') return;

  const map = L.map('leafletMap').setView([-26.2041, 28.0473], 12); // Johannesburg default

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(map);

  L.marker([-26.2041, 28.0473])
    .addTo(map)
    .bindPopup('<strong>Our Office</strong><br>Johannesburg')
    .openPopup();
}

/* ──────────────────────────────────────────────────────────
   14. COUNTER ANIMATION (stats)
──────────────────────────────────────────────────────────── */
function initCounters() {
  $$('.stat-item__num[data-target]').forEach(el => {
    const target  = +el.dataset.target;
    const suffix  = el.dataset.suffix || '';
    const duration = 1800;
    let start     = null;

    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      observer.unobserve(el);
      const step = ts => {
        if (!start) start = ts;
        const progress = Math.min((ts - start) / duration, 1);
        el.textContent = Math.floor(progress * target) + suffix;
        if (progress < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
    observer.observe(el);
  });
}

/* ──────────────────────────────────────────────────────────
   INIT
──────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initScrollTop();
  initAccordions();
  initTabs();
  initLightbox();
  initFilter();
  initScrollAnimations();
  initCounters();
  initDynamicContent();
  initMap();
  // Form pages initialise their own handlers
  initEnquiryForm();
  initContactForm();
});
